package com.dw.teamproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dw.teamproject.model.The8;

public interface The8Repository extends JpaRepository<The8, Long> {

}
