package com.dw.teamproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dw.teamproject.model.BestItem;

public interface BestItemRepository extends JpaRepository<BestItem, Long> {

}
